package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.Employee;
import com.capgemini.repository.EmployeeRepo;

@Service
public class EmployeeService {
	
	
	@Autowired
	EmployeeRepo employeeRepo;
	
	
	public Employee save(Employee emp)
	{
		return (employeeRepo.save(emp));
	}
	
	public List<Employee> findAll()
	{
//		List<Employee> EmployeeRecords = new ArrayList<>();  
//		employeeRepo.findAll().forEach(EmployeeRecords::add); 
		return (List<Employee>) employeeRepo.findAll();
	}
	
	public Employee getEmployee(String id){  
	       
		return employeeRepo.findById(id).get();  
    } 
	
	public void delete(String empNo)
	{
		employeeRepo.deleteById(empNo);
	}

}

package com.capgemini.exception;

@SuppressWarnings("serial")
public class DuplicateMobileNumberException extends Exception {

}

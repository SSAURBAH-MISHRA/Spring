package com.capgemini;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// Using object of ApplicationContext
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee emp = (Employee) context.getBean("emp");
//		Address address=(Address) context.getBean("emp2");
		// Employee emp2=context.getBean("emp", Employee.class);

		// Using object of BeanFactory
		// Resource resource=new ClassPathResource("applicationContext.xml");
		// BeanFactory factory=new XmlBeanFactory(resource);
		// Employee emp=(Employee) factory.getBean("emp");
		System.out.println("Employee ID is "+ emp.getEmpNumber());
		System.out.println("Employee name is "+emp.getName());
		System.out.println("Employee address is "+emp.getAddress().getStreetName()+", "+emp.getAddress().getCityName());
	}

}

package com.capgemini;

public class Employee {
	private int empNumber;
	private String name;
	public Employee() {
		super();
	}
	public int getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [empNumber=" + empNumber + ", name=" + name + "]";
	}
	public Employee(int empNumber, String name) {
		super();
		this.empNumber = empNumber;
		this.name = name;
	}

	
	

}

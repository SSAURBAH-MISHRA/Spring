package com.capgemini;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	@RequestMapping("/hello")
	public Student getStudent()
	{
		Student student=new Student();
		student.setId(101);
		student.setName("Saurabh");
		return student;
		
	}

}

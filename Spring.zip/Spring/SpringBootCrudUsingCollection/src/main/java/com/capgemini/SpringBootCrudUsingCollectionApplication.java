package com.capgemini;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.capgemini.repository")
@ComponentScan("com.capgemini.service")
@ComponentScan("com.capgemini.controller")
@EntityScan("com.capgemini.beans")
public class SpringBootCrudUsingCollectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudUsingCollectionApplication.class, args);
	}

}
